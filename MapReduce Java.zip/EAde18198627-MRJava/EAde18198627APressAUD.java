import java.io.IOException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class EAde18198627APressAUD {
	public static class RateMapper extends Mapper < Object, Text, Text, Text > {
		public void map(Object key, Text value, Context context)
		throws IOException,
		InterruptedException {
			String record = value.toString();//Read each record
			String[] parts = record.split(",");//Parse CSV file
                        System.out.println("Key Column for AUD is" + parts[0]);
			context.write(new Text(parts[0]), new Text("AUD "+ parts[4]));//Label AUD Rate
		}
	}
	
	public static class WeatherMapper extends Mapper < Object, Text, Text, Text > {
		public void map(Object key, Text value, Context context)
		throws IOException,
		InterruptedException {
			String record = value.toString();//Read each record
			String[] parts = record.split(",");//Parse CSV File
                        System.out.println("Key for Atmospheric Pressure" + parts[4]);
			context.write(new Text(parts[4]), new Text("AP "+ parts[5])); //Label Atmospheric Pressure
		}
	}
	
	public static class ReduceJoinReducer extends Reducer < Text, Text, Text, Text > {
		public void reduce(Text key, Iterable < Text > values, Context context)
		throws IOException,
                InterruptedException {
			String AUD = "";
			double total = 0.0;
                        double average = 0.0;
			int count = 0;
			// Here is where the logic of the JOIN/reduction is laid out
			for (Text t: values) {
				String parts[] = t.toString().split(" ");
				if (parts[0].equals("AP")) {
					count++;//count number
					total += Float.parseFloat(parts[1]);//add up their total
				} else if (parts[0].equals("AUD")) {
				 AUD = parts[1]; //count the number of AUD rates
				}
			}
                        average = (total/count);
			String str = String.format("%d %.2f %.2f", count, total, average);
			context.write(new Text(AUD), new Text(str));
			 
		}
	}
	
	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();
		Job job = new Job(conf, "Reduce-side-Join");
		job.setJarByClass(EAde18198627APressAUD.class);
		job.setReducerClass(ReduceJoinReducer.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);
		MultipleInputs.addInputPath(job, new Path(args[0]), TextInputFormat.class, RateMapper.class);
		MultipleInputs.addInputPath(job, new Path(args[1]), TextInputFormat.class, WeatherMapper.class);
		Path outputPath = new Path(args[2]);
		FileOutputFormat.setOutputPath(job, outputPath);
		outputPath.getFileSystem(conf).delete(outputPath);
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}

}


